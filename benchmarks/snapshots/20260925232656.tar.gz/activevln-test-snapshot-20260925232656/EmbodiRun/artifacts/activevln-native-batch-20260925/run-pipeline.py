"""Run six complete closed-loop selections sequentially on physical GPU 1."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/mnt/zhouzhenyuan/activevln-native-batch-20260925')
source = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
old = Path('/mnt/zhouzhenyuan/activevln-benchmark-20260924')
runs = source / 'benchmarks/activevln-benchmark/runs/batch-tree-shared-context'
python = '/root/activevln-venv/bin/python'
env = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(old / 'navigation-runner/src'),
           OMP_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false',
           PYTORCH_ALLOC_CONF='expandable_segments:True,garbage_collection_threshold:0.7')
status = {'status': 'running', 'current': None, 'stages': [], 'physical_gpu': 1}

def save():
    p = root / 'pipeline-status.tmp'
    p.write_text(json.dumps(status, indent=2) + '\n')
    p.replace(root / 'pipeline-status.json')

for split in ('r2r', 'rxr'):
    for batch in (1, 2, 4):
        name = f'{split}-b{batch}'
        output = root / name
        command = [python, '-u', str(root / 'runner/benchmarks/activevln-navigation/benchmark.py'),
                   '--root', str(old), '--source', str(source),
                   '--config', str(runs / f'{name}-config.json'), '--reference-report', str(runs / f'{name}.json'),
                   '--model-python', python, '--habitat-python', '/mnt/zhouzhenyuan/venvs/streamvln-habitat/bin/python',
                   '--serve-script', str(root / 'adapter/serve_batch.py'),
                   '--scenes', '/mnt/zhouzhenyuan/datasets/scene_datasets',
                   '--output', str(output), '--datasets', split, '--batch-size', str(batch)]
        stage = {'name': name, 'command': command, 'started_unix': time.time()}
        status['current'] = name
        status['stages'].append(stage)
        save()
        with (root / f'{name}.log').open('w') as log:
            process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
            stage['pid'] = process.pid
            save()
            stage['returncode'] = process.wait()
        stage['ended_unix'] = time.time()
        save()
status.update(status='finished', current=None)
save()
