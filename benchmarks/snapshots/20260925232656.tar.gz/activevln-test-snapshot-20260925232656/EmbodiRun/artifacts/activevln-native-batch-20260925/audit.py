"""Audit actual executed trajectories and complete paired episode success."""
import collections
import hashlib
import json
import math
from pathlib import Path
import runpy

root = Path(__file__).resolve().parent
old = Path('/mnt/zhouzhenyuan/activevln-benchmark-20260924/navigation-paired-v9')
helpers = runpy.run_path(str(root / 'runner/benchmarks/activevln-navigation/metrics.py'))
result = {'schema': 'activevln.closed_loop_batch_assessment.v1', 'results': {}}

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for split in ('r2r', 'rxr'):
    original = 'candidate-v11-tree-bf16' if split == 'r2r' else 'candidate-v11-rxr-128k'
    for capacity in (1, 2, 4):
        name = f'{split}-b{capacity}'
        folder = root / name
        report_path = folder / f'{split}.json'
        if not report_path.exists():
            continue
        report = read(report_path)
        item = result['results'][name] = {k: report[k] for k in ('status', 'successes', 'sr', 'spl') if k in report}
        item['completed_episodes'] = len(report['episodes'])
        if report['status'] != 'complete':
            failure_path = folder / 'tensor-batches.jsonl'
            if failure_path.exists():
                records = [json.loads(line) for line in failure_path.read_text().splitlines()]
                if records and records[-1]['status'] != 'complete':
                    item['failure'] = records[-1]
            continue
        assert len(report['episodes']) == 48
        batches = [json.loads(line) for line in (folder / 'tensor-batches.jsonl').read_text().splitlines()]
        assert all(batch['status'] == 'complete' and batch['index'] == i for i, batch in enumerate(batches))
        assert all(0 < batch['observations'] <= capacity for batch in batches)
        service = report['model_service']
        assert service['environment']['source_python_sha256'] == '62f8b4dc2bb374c3dbc1610e61e319091eb7b57116a635900bb1fb0dcf51a88f'
        assert service['adapter_sha256'] == digest(root / 'adapter/serve_batch.py')
        assert report['runner_sha256'] == digest(root / 'runner/benchmarks/activevln-navigation/benchmark.py')
        primitive_count = model_calls = initial_matches = invalid = same_original = 0
        maximum_cache = 0
        references = collections.Counter()
        for summary in report['episodes']:
            identity = str(summary['episode_id'])
            episode = read(folder / split / f'episode-{identity}.json')
            prior = read(old / original / split / f'episode-{identity}.json')
            assert episode['status'] == 'complete'
            assert all(summary[k] == v for k, v in episode.items() if k not in ('trace', 'model_service_index'))
            for key in ('start_position', 'start_rotation', 'shortest_path_m', 'habitat_sim_version'):
                assert episode[key] == prior[key], (name, identity, key)
            assert episode['trace'][0]['image_sha256'] == prior['trace'][0]['image_sha256']
            assert digest(folder / split / f'episode-{identity}-initial.png') == episode['trace'][0]['image_sha256']
            initial_matches += 1
            position, length, steps, stopped = episode['start_position'], 0., 0, False
            assert len(episode['trace']) == episode['turns']
            for i, turn in enumerate(episode['trace']):
                assert turn['turn'] == i and turn['before_position'] == position
                batch = turn['model']['tensor_batch']
                assert batch['capacity'] == capacity and batch['observations'] == batches[batch['index']]['observations']
                assert turn['timing']['e2e_ms'] == batches[batch['index']]['latency_ms']
                references[batch['index']] += 1
                model_calls += 1
                maximum_cache = max(maximum_cache, turn['model']['cache_length'])
                if 'invalid_action' in turn:
                    assert episode['termination'] == 'invalid_action' and i == len(episode['trace']) - 1
                    invalid += 1
                    continue
                actual = turn['executed']
                expected = helpers['primitive_actions'](turn['model']['rows'])[:500 - steps]
                assert [movement['action'] for movement in actual] == expected
                for movement in actual:
                    assert not stopped
                    length += math.dist(position, movement['position'])
                    position = movement['position']
                    stopped = movement['action'] == 0
                    steps += 1
                assert turn['distance_to_goal_m'] == actual[-1]['distance_to_goal_m']
            assert episode['steps'] == steps and episode['stopped'] == stopped
            assert abs(episode['path_length_m'] - length) < 1e-4
            assert episode['distance_to_goal_m'] == episode['trace'][-1].get('distance_to_goal_m', episode['distance_to_goal_m'])
            primitive_count += steps
            same_original += len(episode['trace']) == len(prior['trace']) and all(
                all(a['model'][key] == b['model'][key] for key in ('token_ids', 'rows', 'cache_length'))
                and a.get('executed') == b.get('executed')
                for a, b in zip(episode['trace'], prior['trace']))
        assert references == {batch['index']: batch['observations'] for batch in batches}
        assert sum(batch['observations'] for batch in batches) == model_calls
        total_ms = sum(batch['latency_ms'] for batch in batches)
        item.update(initial_pose_rgb_matches=initial_matches, primitive_steps=primitive_count,
                    model_observations=model_calls, tensor_batches=len(batches),
                    occupancy_counts=dict(collections.Counter(batch['observations'] for batch in batches)),
                    invalid_actions=invalid, max_cache_length=maximum_cache,
                    mean_batch_e2e_ms=total_ms / len(batches),
                    mean_batch_forward_ms=sum(batch['model_timing_ms']['pure_inference_ms'] for batch in batches) / len(batches),
                    amortized_e2e_ms_per_observation=total_ms / model_calls,
                    peak_allocated_gib=max(batch['peak_allocated_bytes'] for batch in batches) / 2**30,
                    peak_reserved_gib=max(batch['peak_reserved_bytes'] for batch in batches) / 2**30,
                    final_runtime=batches[-1]['runtime'], original_b1_identical_episodes=same_original,
                    compared_original_b1=helpers['compare'](read(old / original / f'{split}.json'), report),
                    compared_unoptimized_baseline=helpers['compare'](read(old / 'baseline' / f'{split}.json'), report))
        new_b1 = root / f'{split}-b1' / f'{split}.json'
        if new_b1.exists() and read(new_b1)['status'] == 'complete':
            item['compared_current_b1'] = helpers['compare'](read(new_b1), report)

temporary = root / 'assessment.tmp'
temporary.write_text(json.dumps(result, indent=2) + '\n')
temporary.replace(root / 'assessment.json')
print(json.dumps({name: {k: v for k, v in item.items() if k in ('status', 'successes', 'sr', 'spl', 'completed_episodes', 'original_b1_identical_episodes', 'occupancy_counts')} for name, item in result['results'].items()}, indent=2))
