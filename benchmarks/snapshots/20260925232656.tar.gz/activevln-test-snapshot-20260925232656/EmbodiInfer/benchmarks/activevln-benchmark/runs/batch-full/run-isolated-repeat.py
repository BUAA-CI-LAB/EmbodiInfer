import json,os,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent
runs=root/'benchmarks/activevln-benchmark/runs/batch-full'
while True:
    try: status=json.loads((runs/'pipeline-status.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError): status={'current':'pending'}
    if status['current'] is None: break
    time.sleep(5)
name='r2r-b2-isolated'
cfg=json.loads((runs/'r2r-b2-config.json').read_text())
(runs/(name+'-config.json')).write_text(json.dumps(cfg,indent=2)+'\n')
(runs/'isolated-status.json').write_text(json.dumps({'status':'running','reason':'Repeat without the overlapping CPU regression process present during the first R2R B2 run.'}))
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='1',PYTHONPATH=str(root),OMP_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True,garbage_collection_threshold:0.7')
with (runs/(name+'.log')).open('w') as log:
    p=subprocess.run(['/root/activevln-venv/bin/python','-u',str(root/'benchmarks/activevln-benchmark/benchmark_batch.py'),'--config',str(runs/(name+'-config.json')),'--output',str(runs/(name+'.json'))],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(runs/'isolated-status.json').write_text(json.dumps({'status':'finished','returncode':p.returncode}))
