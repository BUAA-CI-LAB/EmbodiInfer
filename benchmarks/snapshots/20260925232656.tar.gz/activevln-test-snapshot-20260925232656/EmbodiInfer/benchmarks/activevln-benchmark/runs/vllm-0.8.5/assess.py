"""Validate complete reports and compare only matching recorded observations."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
baseline = root.parent/'batch-tree-shared-context'
result = {'scope':'B1 fixed-frame replay; full own history; no closed-loop SR/SPL claim', 'splits':{}}
inputs=[root/f'{name}-cpu-inputs.json' for name in ['embodiinfer','vllm']]
if all(p.exists() for p in inputs):
    first,second=[json.loads(p.read_text()) for p in inputs]
    assert first['rows']==second['rows']
    assert len(first['rows'])==192
    result['cross_environment_inputs']={'matched':len(first['rows']),'packages':{'embodiinfer':first['packages'],'vllm':second['packages']},'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
for name in ['r2r-full','r2r-dedup-full','rxr-dedup-full']:
    split=name.split('-')[0]
    path=root/f'{name}.json'
    if not path.exists():
        continue
    actual=json.loads(path.read_text())
    reference=json.loads((baseline/f'{split}-b1.json').read_text())
    if actual['status'] != 'complete':
        result['splits'][name]={'status':actual['status'],'calls':len(actual['rows'])}
        continue
    assert actual['reference_config'] == reference['config']
    assert actual['selection'] == reference['selection']
    assert actual['selection_sha256'] == reference['selection_sha256']
    rows=actual['rows']
    expected={(s['episode_id'],n) for s in actual['selection'] for n in range(s['frames'])}
    keys=[(r['episode_id'],r['step']) for r in rows]
    assert len(keys)==len(set(keys)) and set(keys)==expected
    assert all(r['history_images']==r['step']+1 for r in rows)
    assert all(r['vision_calls']==1 for r in rows)
    assert all(0 < r['model_timing_ms']['pure_inference_ms'] <= r['latency_ms'] for r in rows)
    assert all(r['graph_steps']+r['non_graph_steps']==r['engine_steps'] for r in rows)
    assert all(r['generated_tokens']==len(r['token_ids']) for r in rows)
    audits=[r['input_audit'] for r in rows if 'input_audit' in r]
    assert len(audits)==2*len(actual['selection'])
    assert all(all(a[k] for k in ['tokens_equal','pixels_equal','grid_equal']) for a in audits)
    lookup={(r['episode_id'],r['step']):r for r in reference['rows']}
    stats={
        'status':'complete','calls':len(rows),'episodes':len(actual['selection']),
        'report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'benchmark_sha256':actual['benchmark_sha256'],
        'deduplicate_placeholder_updates':actual.get('deduplicate_placeholder_updates',False),
        'environment':actual['environment'],
        'vllm_metrics':actual['metrics'], 'embodiinfer_metrics':reference['metrics'],
        'vllm_peak_gib':{k:v/(1024**3) for k,v in actual['memory'].items()},
        'input_audits_passed':len(audits),
        'invalid_actions':sum(not r['parsed_valid'] for r in rows),
        'stop_reasons':dict(Counter(r['stop_reason'] for r in rows)),
        'max_prompt_tokens':max(r['prompt_tokens'] for r in rows),
        'graph_steps':sum(r['graph_steps'] for r in rows),
        'non_graph_steps':sum(r['non_graph_steps'] for r in rows),
        'noninitial_prefix_hits':sum(r['step']>0 and r['prefix_cached_tokens']>0 for r in rows),
        'noninitial_calls':sum(r['step']>0 for r in rows),
        'generated_tokens_mean':statistics.mean(r['generated_tokens'] for r in rows),
        'baseline_generated_tokens_mean':statistics.mean(len(r['token_ids']) for r in reference['rows']),
        'token_equal_calls':sum(r['token_ids']==lookup[r['episode_id'],r['step']]['token_ids'] for r in rows),
        'action_equal_calls':sum(r['actions']==lookup[r['episode_id'],r['step']]['actions'] for r in rows),
        'admission_ms_mean':statistics.mean(r['cpu_preparation_and_admission_ms'] for r in rows),
        'e2e_overhead_ms_mean':statistics.mean(r['latency_ms']-r['model_timing_ms']['pure_inference_ms'] for r in rows),
        'mean_ms_by_episode_step':{},
    }
    for low,high in [(0,1),(1,16),(16,32),(32,64),(64,96),(96,148)]:
        bucket=[r for r in rows if low<=r['step']<high]
        if bucket:
            stats['mean_ms_by_episode_step'][f'{low}:{high}']={
                'calls':len(bucket),
                'e2e':statistics.mean(r['latency_ms'] for r in bucket),
                'forward':statistics.mean(r['model_timing_ms']['pure_inference_ms'] for r in bucket),
                'tokens':statistics.mean(r['generated_tokens'] for r in bucket),
            }
    if actual.get('deduplicate_placeholder_updates'):
        assert all(r['placeholder_rules_before']==r['history_images'] and r['placeholder_rules_after']==1 for r in rows)
        original_path=root/('r2r-full.json' if split=='r2r' else 'rxr-original-partial.json')
        original=json.loads(original_path.read_text())
        native_lookup={(r['episode_id'],r['step']):r for r in rows}
        different=[]
        for r in original['rows']:
            now=native_lookup[r['episode_id'],r['step']]
            fields=[k for k in ['token_ids','actions','action_mask','cache_length','prompt_tokens','prefix_cached_tokens'] if now[k]!=r[k]]
            if fields:different.append({'episode_id':r['episode_id'],'step':r['step'],'fields':fields})
        assert not different, different[:10]
        stats['native_original_parity']={'calls':len(original['rows']),'different':0,'reference':original_path.name,'reference_complete':original['status']=='complete'}
    result['splits'][name]=stats
result['complete']=all(result['splits'].get(k,{}).get('status')=='complete' for k in ['r2r-full','r2r-dedup-full','rxr-dedup-full'])
out=root/'assessment.json';out.write_text(json.dumps(result,indent=2)+'\n')
for split,r in result['splits'].items():
    print(split,json.dumps(r,ensure_ascii=False))
