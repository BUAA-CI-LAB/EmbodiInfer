"""Validate the frontend-only fix, then run complete native GPU-1 comparisons."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/mnt/zhouzhenyuan/activevln-vllm-20260925')
source = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
python = '/mnt/zhouzhenyuan/venvs/activevln-vllm-0.8.5/bin/python'
benchmark = root/'benchmarks/activevln-benchmark/benchmark_vllm.py'
env = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(source),
           OMP_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false',
           VLLM_USE_V1='1', VLLM_ENABLE_V1_MULTIPROCESSING='0',
           VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1', HF_HUB_OFFLINE='1',
           TRANSFORMERS_OFFLINE='1', TORCHINDUCTOR_COMPILE_THREADS='4',
           TORCHINDUCTOR_CACHE_DIR='/tmp/activevln-vllm085-inductor',
           TMPDIR=str(root/'tmp'))
state = {'status':'starting', 'supervisor_pid':os.getpid(), 'started_unix':time.time(),
         'benchmark_sha256':hashlib.sha256(benchmark.read_bytes()).hexdigest(), 'runs':[]}
def save():
    p=root/'dedup-status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'dedup-status.json')
save()
try:
    for split,phase in [('r2r','probe'),('r2r','full'),('rxr','full')]:
        memory=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
        assert int(memory.strip()) < 100, 'GPU1 is occupied'
        assert hashlib.sha256(benchmark.read_bytes()).hexdigest() == state['benchmark_sha256']
        name=f'{split}-dedup-{phase}'
        output=root/f'{name}.json'
        assert not output.exists(), f'refusing to overwrite {output}'
        command=[python,'-u',str(benchmark),'--config',str(source/f'benchmarks/activevln-benchmark/runs/batch-tree-shared-context/{split}-b1-config.json'),'--output',str(output),'--deduplicate-placeholder-updates']
        if phase=='probe':command+=['--max-steps-per-episode','2']
        run={'split':split,'phase':phase,'command':command,'started_unix':time.time()}
        state['runs'].append(run);state.update(status='running',current=name);save()
        with (root/f'{name}.log').open('x') as log:
            process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
            run['pid']=process.pid;save();run['returncode']=process.wait()
        run['ended_unix']=time.time();save()
        if run['returncode']:raise RuntimeError(f'{name} failed: {run["returncode"]}')
        report=json.loads(output.read_text())
        assert report['status']==('partial_probe' if phase=='probe' else 'complete')
        assert all(r['placeholder_rules_before']==r['history_images'] and r['placeholder_rules_after']==1 for r in report['rows'])
        original_name='r2r-probe-default-graphs.json' if phase=='probe' else 'r2r-full.json' if split=='r2r' else 'rxr-original-partial.json'
        original=json.loads((root/original_name).read_text())
        lookup={(r['episode_id'],r['step']):r for r in report['rows']}
        mismatches=[]
        for row in original['rows']:
            actual=lookup[row['episode_id'],row['step']]
            changed=[k for k in ['token_ids','actions','action_mask','cache_length','prompt_tokens','prefix_cached_tokens'] if row[k]!=actual[k]]
            if changed:mismatches.append({'episode_id':row['episode_id'],'step':row['step'],'fields':changed})
        run['parity']={'original':original_name,'compared_calls':len(original['rows']),'mismatches':mismatches};save()
        if mismatches:raise RuntimeError(f'{name}: frontend-only fix changed outputs')
    state.update(status='complete',ended_unix=time.time());save()
except BaseException as error:
    state.update(status='error',error=repr(error),ended_unix=time.time());save()
if state['status']=='complete':
    previous=Path('/proc/2499022/cmdline')
    if previous.exists() and b'run-pipeline.py' in previous.read_bytes():
        os.kill(2499022,signal.SIGCONT)
        state['quality_pipeline_resumed_pid']=2499022
    else:
        state['quality_pipeline_resume_error']='Original supervisor no longer matches'
    save()
