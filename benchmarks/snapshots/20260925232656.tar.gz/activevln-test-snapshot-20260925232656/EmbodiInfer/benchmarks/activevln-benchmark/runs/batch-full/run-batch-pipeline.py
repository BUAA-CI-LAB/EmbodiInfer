import json,os,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent
runs=root/'benchmarks/activevln-benchmark/runs/batch-full'
env=os.environ.copy()
env.update(CUDA_VISIBLE_DEVICES='1',PYTHONPATH=str(root),OMP_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True,garbage_collection_threshold:0.7')
results=[]
for name in ['r2r-b4-smoke','r2r-b2','r2r-b4','rxr-b2','rxr-b4']:
    status={'current':name,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'results':results}
    (runs/'pipeline-status.json').write_text(json.dumps(status,indent=2))
    with (runs/(name+'.log')).open('w') as log:
        result=subprocess.run(['/root/activevln-venv/bin/python','-u',str(root/'benchmarks/activevln-benchmark/benchmark_batch.py'),'--config',str(runs/(name+'-config.json')),'--output',str(runs/(name+'.json'))],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append({'name':name,'returncode':result.returncode})
    if name.endswith('smoke') and result.returncode: break
(runs/'pipeline-status.json').write_text(json.dumps({'current':None,'results':results},indent=2))
