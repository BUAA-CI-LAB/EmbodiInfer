"""Audit complete recorded workloads and separate batching throughput from latency."""

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = "a747f0213bc113c3bb949d5ede764610918b12e7908bf0714cb3aaff59a2a977"
RUNS = ("r2r-b2-isolated", "r2r-b4", "rxr-b2", "rxr-b4")


def digest(path: Path) -> str:
    """Hash a raw report without reserializing it."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """Verify recorded conditions and produce a scoped assessment."""
    results = []
    for name in RUNS:
        path = ROOT / (name + ".json")
        report = json.loads(path.read_text())
        cfg = report["config"]
        assert report["environment"]["source_python_sha256"] == SOURCE
        assert report["cuda_visible_devices"] == "1"
        assert cfg["dtype"] == "bfloat16" and cfg["seed"] == 42
        assert cfg["max_new_tokens"] == 512 and cfg["max_context"] == 128000
        assert cfg["warmup_calls"] == 33 and cfg["repetition_penalty"] == 1.05
        assert cfg["cuda_graph"] and cfg["fused_ops"] and cfg["split_attention"]
        assert not cfg["do_sample"] and not cfg["tree_decode"]
        assert cfg["query_bucket_size"] == 32 and cfg["max_steps_per_episode"] is None
        assert cfg["checkpoint_revision"] == "160987313e3e869705f42400d1b8f28177044518"
        expected = {
            (episode["episode_id"], step)
            for episode in report["selection"]
            for step in range(episode["frames"])
        }
        episode_ids = [ep["episode_id"] for ep in report["selection"]]
        assert len(episode_ids) == 48 and episode_ids == sorted(set(episode_ids))
        assert len(expected) == {"R2R": 2997, "RxR": 3879}[report["dataset"]]
        observed = [(row["episode_id"], row["step"]) for row in report["rows"]]
        observed_set = set(observed)
        assert len(observed_set) == len(observed) and observed_set <= expected
        if report["status"] == "complete":
            assert observed_set == expected and report["phase"] == "finished"
        else:
            assert report["status"] == "oom", report.get("exception")
        assert sum(batch["observations"] for batch in report["batches"]) == len(observed)
        group = Counter(row["batch_index"] for row in report["rows"])
        for batch in report["batches"]:
            assert group[batch["batch_index"]] == batch["observations"]
            assert 1 <= batch["observations"] <= report["batch_size"]
        memory = report["memory"]
        allocated = max(
            memory["peak_allocated_bytes"], report.get("startup_memory", {}).get("peak_allocated_bytes", 0)
        )
        reserved = max(
            memory["peak_reserved_bytes"], report.get("startup_memory", {}).get("peak_reserved_bytes", 0)
        )
        results.append(
            {
                "file": path.name,
                "sha256": digest(path),
                "dataset": report["dataset"],
                "batch_size": report["batch_size"],
                "status": report["status"],
                "observations": len(observed),
                "expected_observations": len(expected),
                "completed_episodes": sum(
                    all((ep["episode_id"], i) in observed_set for i in range(ep["frames"]))
                    for ep in report["selection"]
                ),
                "max_cache_length": max((row["cache_length"] for row in report["rows"]), default=0),
                "invalid_actions": sum(not row["parsed_valid"] for row in report["rows"]),
                "metrics": report["metrics"],
                "peak_allocated_gib": allocated / 2**30,
                "peak_reserved_gib": reserved / 2**30,
                "startup_memory": report.get("startup_memory"),
                "measurement_memory": memory,
                "runtime": report.get("runtime"),
                "failure_phase": report["phase"] if report["status"] != "complete" else None,
                "exception": report.get("exception"),
                "inflight_batch": report.get("inflight_batch"),
            }
        )
    first = json.loads((ROOT / "r2r-b2.json").read_text())
    isolated = json.loads((ROOT / "r2r-b2-isolated.json").read_text())
    original_rows = {(x["episode_id"], x["step"]): x for x in first["rows"]}
    isolated_rows = {(x["episode_id"], x["step"]): x for x in isolated["rows"]}
    assert original_rows.keys() == isolated_rows.keys()
    repeat_check = {
        "observations": len(original_rows),
        "different_token_sequences": sum(
            original_rows[k]["token_ids"] != isolated_rows[k]["token_ids"] for k in original_rows
        ),
        "different_actions": sum(
            original_rows[k]["actions"] != isolated_rows[k]["actions"] for k in original_rows
        ),
        "different_cache_lengths": sum(
            original_rows[k]["cache_length"] != isolated_rows[k]["cache_length"] for k in original_rows
        ),
        "first_batch_e2e_ms": first["metrics"]["batch_e2e_ms"]["mean"],
        "isolated_batch_e2e_ms": isolated["metrics"]["batch_e2e_ms"]["mean"],
    }
    output = {
        "schema": "activevln.tensor_batch_assessment.v1",
        "source_python_sha256": SOURCE,
        "runs": results,
        "navigation_quality_admitted": None,
        "accuracy_scope": "Fixed trajectory replay, not SR/SPL. Existing B=1 navigation scores do not certify the batched implementation.",
        "latency_scope": "Mean E2E/forward are for the whole batch. Amortized per-observation time is throughput cost, not single-request latency.",
        "baseline_scope": "The earlier 70.23/104.45-ms B=1 profiles used action trees. These runs disable trees and use query bucket 32; no direct batching speedup versus those configurations is claimed.",
        "selection_note": "R2R B2 uses the isolated rerun because the first run overlapped briefly with CPU regression tests. The first report is diagnostic only.",
        "r2r_b2_repeat_check": repeat_check,
    }
    (ROOT / "assessment.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
