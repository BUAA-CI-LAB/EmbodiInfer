"""Audit CPU inputs between GPU stages, never during measured GPU replay."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root=Path('/mnt/zhouzhenyuan/activevln-vllm-20260925')
parent=2509509
assert b'run-dedup.py' in Path(f'/proc/{parent}/cmdline').read_bytes()
os.kill(parent,signal.SIGSTOP)
state={'status':'waiting_r2r_exit','supervisor_pid':parent,'started_unix':time.time()}
def save():
    p=root/'cross-env-audit-status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'cross-env-audit-status.json')
save()
try:
    while Path('/proc/2509805/stat').exists() and Path('/proc/2509805/stat').read_text().split()[2]!='Z':time.sleep(1)
    memory=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
    assert int(memory.strip())<100
    state['status']='auditing';save()
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='1',PYTHONPATH='/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    for name,python in [('embodiinfer','/root/activevln-venv/bin/python'),('vllm','/mnt/zhouzhenyuan/venvs/activevln-vllm-0.8.5/bin/python')]:
        with (root/f'{name}-cpu-inputs.log').open('w') as log:
            subprocess.run([python,str(root/'audit-inputs.py'),'--output',str(root/f'{name}-cpu-inputs.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    first=json.loads((root/'embodiinfer-cpu-inputs.json').read_text());second=json.loads((root/'vllm-cpu-inputs.json').read_text())
    assert first['rows']==second['rows'],'Cross-environment preprocessing differs'
    state.update(status='complete',matching_inputs=len(first['rows']),ended_unix=time.time());save()
except BaseException as error:
    state.update(status='error',error=repr(error),ended_unix=time.time());save()
finally:
    if b'run-dedup.py' in Path(f'/proc/{parent}/cmdline').read_bytes():
        os.kill(parent,signal.SIGCONT);state['supervisor_resumed']=True;save()
