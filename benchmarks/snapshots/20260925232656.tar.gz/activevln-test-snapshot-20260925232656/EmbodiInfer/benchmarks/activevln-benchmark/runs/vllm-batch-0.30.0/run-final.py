import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/mnt/zhouzhenyuan/activevln-vllm-batch-0.30.0-20260925')
SOURCE = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
PYTHON = '/mnt/zhouzhenyuan/venvs/activevln-vllm-0.30.0/bin/python'
BENCH = ROOT / 'final/benchmarks/activevln-benchmark/benchmark_vllm_batch.py'
ENV = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(SOURCE), OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false', VLLM_ENABLE_V1_MULTIPROCESSING='0', VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TORCHINDUCTOR_COMPILE_THREADS='4', TORCHINDUCTOR_CACHE_DIR='/tmp/activevln-vllm030-inductor', TMPDIR=str(ROOT / 'tmp'))
ENV.pop('ARCTIC_INFERENCE_ENABLED', None)
STATE = {'status':'running','physical_gpu':1,'stages':[], 'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in BENCH.parent.glob('*.py')}}

def save():
    (ROOT / 'batch-final-status.tmp').write_text(json.dumps(STATE, indent=2)+'\n')
    (ROOT / 'batch-final-status.tmp').replace(ROOT / 'batch-final-status.json')

def stage(name, command):
    assert all(hashlib.sha256((BENCH.parent / name).read_bytes()).hexdigest()==value for name,value in STATE['source_sha256'].items())
    entry={'name':name,'command':command,'started_unix':time.time()}
    STATE['stages'].append(entry)
    STATE['current']=name
    with (ROOT / (name+'.log')).open('w') as log:
        process=subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=ENV, cwd=ROOT)
        entry['pid']=process.pid
        save()
        entry['returncode']=process.wait()
    entry['ended_unix']=time.time()
    save()
    return entry['returncode']

try:
    tests=[str(p) for p in sorted((ROOT / 'final/tests').glob('test_*.py'))]
    assert stage('tests-final-capture', [PYTHON,'-m','pytest','-q',*tests])==0
    for split,batch,limit in [('r2r',2,None),('r2r',4,None),('rxr',2,None),('rxr',4,None)]:
        name=f'{split}-b{batch}-'+('smoke' if limit else 'full')
        config=SOURCE / f'benchmarks/activevln-benchmark/runs/batch-tree-shared-context/{split}-b{batch}-config.json'
        command=[PYTHON,'-u',str(BENCH),'--config',str(config),'--output',str(ROOT / (name+'.json'))]
        if limit:
            command += ['--max-steps-per-episode',str(limit)]
        code=stage(name,command)
        report=json.loads((ROOT/(name+'.json')).read_text())
        if report['status']=='oom' and not limit:
            continue
        assert code==0, report.get('exception')
        assert len(report['rows'])==report['expected_observations']
        assert len({(r['episode_id'],r['step']) for r in report['rows']})==len(report['rows'])
        assert all(r['parsed_valid'] for r in report['rows'])
        assert all(b['vision_items']==b['observations'] and b['vision_graph_hits']>0 and b['vision_graph_misses']==0 for b in report['batches'])
        assert all(b['graph_modes'].get('NONE',0)==0 for b in report['batches'])
        if batch==1:
            ref=json.loads(Path('/mnt/zhouzhenyuan/activevln-vllm-0.30.0-20260925/r2r-full-final.json').read_text())
            lookup={(r['episode_id'],r['step']):r for r in ref['rows']}
            differences=sum(row['token_ids']!=lookup[(row['episode_id'],row['step'])]['token_ids'] for row in report['rows'])
            STATE['b1_harness_token_differences']=differences
            save()
            assert differences==0, 'B1 harness changed generated histories'
    STATE['status']='finished'
except Exception as exc:
    STATE.update(status='failed',error=repr(exc))
finally:
    save()
