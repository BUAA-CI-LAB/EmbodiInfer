"""Compare CPU preprocessing bytes across the isolated deployment environments."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

root=Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
sys.path.insert(0,str(root/'benchmarks/activevln-benchmark'))
from benchmark import load_navigation,read_rgb
from embodiinfer.policies.activevln.prompt_activevln import render_turn_text
from PIL import Image
from transformers import AutoProcessor
import torch

arg=argparse.ArgumentParser();arg.add_argument('--output',type=Path,required=True);args=arg.parse_args()
torch.set_num_threads(1)
processor=AutoProcessor.from_pretrained('/mnt/zhouzhenyuan/checkpoints/activevln-complete',local_files_only=True,use_fast=False)
report={'packages':{p:importlib.metadata.version(p) for p in ['torch','numpy','Pillow','transformers']},'rows':[]}
for split in ['r2r','rxr']:
    config=json.loads((root/f'benchmarks/activevln-benchmark/runs/batch-tree-shared-context/{split}-b1-config.json').read_text())
    for ep in load_navigation(config['datasets'][0]):
        for index,path in enumerate(ep.frames[:2]):
            rgb=read_rgb(path)
            text=render_turn_text(processor,ep.instruction,initial=index==0)
            inputs=processor(text=[text],images=[Image.fromarray(rgb)],return_tensors='pt',padding=False)
            row={'dataset':split,'episode_id':ep.episode_id,'step':index,'rgb_sha256':hashlib.sha256(rgb.tobytes()).hexdigest()}
            for key in ['input_ids','pixel_values','image_grid_thw']:
                t=inputs[key];row[key]={'shape':list(t.shape),'dtype':str(t.dtype),'sha256':hashlib.sha256(t.numpy().tobytes()).hexdigest()}
            report['rows'].append(row)
args.output.write_text(json.dumps(report,indent=2)+'\n');print('Audited',len(report['rows']),'CPU inputs')
