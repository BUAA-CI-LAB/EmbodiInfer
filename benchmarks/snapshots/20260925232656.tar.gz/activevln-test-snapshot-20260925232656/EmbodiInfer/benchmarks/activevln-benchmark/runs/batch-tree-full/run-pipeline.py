"""Run the six fixed replay measurements sequentially on physical GPU 1."""
import json
import os
from pathlib import Path
import subprocess
import time

runs = Path(__file__).resolve().parent
root = runs.parents[3]
env = os.environ.copy()
env.update(CUDA_VISIBLE_DEVICES="1", PYTHONPATH=str(root), OMP_NUM_THREADS="4", TOKENIZERS_PARALLELISM="false", PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True,garbage_collection_threshold:0.7")
results = []
for split in ("r2r", "rxr"):
    for batch in (1, 2, 4):
        name = f"{split}-b{batch}"
        (runs / "pipeline-status.json").write_text(json.dumps({"current": name, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "results": results}, indent=2))
        start = time.monotonic()
        with (runs / f"{name}.log").open("w") as log:
            completed = subprocess.run(["/root/activevln-venv/bin/python", "-u", str(root / "benchmarks/activevln-benchmark/benchmark_batch.py"), "--config", str(runs / f"{name}-config.json"), "--output", str(runs / f"{name}.json")], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        results.append({"name": name, "returncode": completed.returncode, "wall_seconds": time.monotonic() - start})
(runs / "pipeline-status.json").write_text(json.dumps({"current": None, "results": results}, indent=2))
