"""Audit saved reports without rerunning inference or changing measurements."""

import hashlib
import json
from pathlib import Path


RUNS = Path(__file__).resolve().parent
EXPECTED_SOURCE = "62f8b4dc2bb374c3dbc1610e61e319091eb7b57116a635900bb1fb0dcf51a88f"
GENERATION = (
    "checkpoint_revision", "dtype", "seed", "attention", "max_new_tokens",
    "max_context", "do_sample", "repetition_penalty", "cpu_threads",
    "warmup_calls", "cuda_graph", "fused_ops", "split_attention", "tree_decode",
    "query_bucket_size", "tree_fp32_projection", "tree_repeat_actions",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows_by_key(report):
    rows = {(row["episode_id"], row["step"]): row for row in report["rows"]}
    assert len(rows) == len(report["rows"]), "duplicate episode/frame"
    return rows


def compare_outputs(reference, candidate):
    left, right = rows_by_key(reference), rows_by_key(candidate)
    common = sorted(left.keys() & right.keys())
    first_difference = {}
    for key in common:
        if left[key]["token_ids"] != right[key]["token_ids"]:
            first_difference.setdefault(str(key[0]), key[1])
    return {
        "common_frames": len(common),
        "same_token_frames": sum(left[k]["token_ids"] == right[k]["token_ids"] for k in common),
        "same_action_frames": sum(left[k]["output_sha256"] == right[k]["output_sha256"] for k in common),
        "same_cache_length_frames": sum(left[k]["cache_length"] == right[k]["cache_length"] for k in common),
        "first_token_difference_step_by_episode": first_difference,
        "scope": "Descriptive fixed replay with independently generated histories; not SR/SPL or teacher-forced numerical parity.",
    }


def main():
    assessment = {
        "schema": "activevln.feature_matched_batch_assessment.v1",
        "source_python_sha256": EXPECTED_SOURCE,
        "runs": [], "comparisons": [], "legacy_b1_comparisons": [], "context_graph_sharing_parity": [],
        "accuracy_scope": "No new closed-loop SR/SPL measurement; old B=1 scores do not certify multi-batch quality.",
    }
    for split, expected in (("r2r", 2997), ("rxr", 3879)):
        reports = {}
        legacy_path = RUNS.parent / "batch-tree-validation/legacy-b1" / f"{split}.json"
        legacy = json.loads(legacy_path.read_text())
        expected_keys = set(rows_by_key(legacy))
        assert len(expected_keys) == expected
        for batch in (1, 2, 4):
            path = RUNS / f"{split}-b{batch}.json"
            r = json.loads(path.read_text())
            assert r["environment"]["source_python_sha256"] == EXPECTED_SOURCE
            assert r["cuda_visible_devices"] == "1"
            assert r["expected_observations"] == expected
            assert len(r["selection"]) == 48
            planned = {(row["episode_id"], step) for row in r["selection"] for step in range(row["frames"])}
            assert planned == expected_keys
            actual = set(rows_by_key(r))
            assert actual <= planned
            assert r["status"] in ("complete", "oom", "error")
            if r["status"] == "complete":
                assert actual == planned
            for field in GENERATION:
                assert r["config"][field] == legacy["config"][field], (split, batch, field)
            if reports:
                ref_config = {k: v for k, v in reports[1]["config"].items() if k not in ("batch_size", "output_dir", "kv_pool_tokens")}
                candidate_config = {k: v for k, v in r["config"].items() if k not in ("batch_size", "output_dir", "kv_pool_tokens")}
                assert ref_config == candidate_config
                assert r["selection_sha256"] == reports[1]["selection_sha256"]
                assert r["allocator_config"] == reports[1]["allocator_config"]
            reports[batch] = r
            assert r["config"]["kv_pool_tokens"] == (153600 if split == "rxr" and batch == 4 else 128000)
            runtime = r.get("runtime", {})
            counts = {k: v for k, v in runtime.items() if not isinstance(v, (list, dict))}
            entry = {
                "file": path.name, "sha256": digest(path), "dataset": r["dataset"],
                "batch_size": batch, "status": r["status"], "phase": r["phase"],
                "observations": len(r["rows"]), "expected_observations": expected,
                "completed_episodes": sum(all((e["episode_id"], step) in actual for step in range(e["frames"])) for e in r["selection"]),
                "invalid_actions": sum(not row["parsed_valid"] for row in r["rows"]),
                "max_cache_length": max((row["cache_length"] for row in r["rows"]), default=0),
                "generated_tokens": sum(len(row["token_ids"]) for row in r["rows"]),
                "mean_generated_tokens_per_observation": sum(len(row["token_ids"]) for row in r["rows"]) / len(r["rows"]) if r["rows"] else None,
                "cpu_prepost_and_transfer_ms": r["metrics"]["batch_e2e_ms"]["mean"] - r["metrics"]["batch_forward_ms"]["mean"] if r["batches"] else None,
                "metrics": r["metrics"],
                "peak_allocated_gib": r["memory"]["peak_allocated_bytes"] / 2**30,
                "peak_reserved_gib": r["memory"]["peak_reserved_bytes"] / 2**30,
                "startup_memory": r.get("startup_memory"),
                "runtime": counts,
            }
            if "exception" in r:
                entry.update(exception=r["exception"], inflight_batch=r.get("inflight_batch"))
            if r["status"] == "complete":
                assert not entry["invalid_actions"]
                assert runtime["tree_accepted_tokens"] > 0
                assert runtime["fused_ops"] and runtime["split_attention"] and runtime["tree_decode"]
                assert runtime["capacity_growths"] == 0
                entry["graph_fallbacks"] = {k: runtime[k] for k in ("vision_fallbacks", "prefill_fallbacks", "decode_fallbacks", "tree_fallbacks")}
                entry["prefill_padding_fraction"] = runtime["prefill_padding_tokens"] / (runtime["prefill_actual_tokens"] + runtime["prefill_padding_tokens"])
                entry["tree_accepted_tokens_per_verified_row"] = runtime["tree_accepted_tokens"] / runtime["tree_verified_rows"]
                entry["tree_padding_to_candidate_node_ratio"] = runtime["tree_padding_nodes"] / runtime["tree_candidate_nodes"]
            assessment["runs"].append(entry)
            previous_path = RUNS.parent / "batch-tree-full" / path.name
            if previous_path.exists():
                previous = json.loads(previous_path.read_text())
                if previous["status"] == r["status"] == "complete":
                    parity = compare_outputs(previous, r)
                    assert all(parity[field] == expected for field in ("common_frames", "same_token_frames", "same_action_frames", "same_cache_length_frames"))
                    assert previous["runtime"]["text_shapes"] == runtime["text_shapes"]
                    assessment["context_graph_sharing_parity"].append({
                        "dataset": split, "batch_size": batch,
                        "previous_report_sha256": digest(previous_path),
                        "same_tokens_actions_and_cache_lengths": True,
                        "frames": expected, "logical_text_shapes": runtime["text_graphs"],
                        "text_graph_executables": runtime["text_graph_executables"],
                        "tree_graph_executables": runtime["tree_graph_executables"],
                    })
        for batch in (2, 4):
            base, candidate = reports[1], reports[batch]
            comparison = {"dataset": split, "batch_size": batch, "same_frame_selection_and_switches": True,
                          "outputs": compare_outputs(base, candidate)}
            if base["status"] == candidate["status"] == "complete":
                comparison.update(
                    throughput_speedup_vs_b1=candidate["metrics"]["observations_per_second"] / base["metrics"]["observations_per_second"],
                    whole_batch_latency_ratio_vs_b1=candidate["metrics"]["batch_e2e_ms"]["mean"] / base["metrics"]["batch_e2e_ms"]["mean"],
                )
            assessment["comparisons"].append(comparison)
        assessment["legacy_b1_comparisons"].append({
            "dataset": split, "legacy_report_sha256": digest(legacy_path),
            "legacy_e2e_ms": legacy["metrics"]["latency_ms"]["mean"],
            "legacy_forward_ms": legacy["metrics"]["model_timing_ms"]["pure_inference_ms"]["mean"],
            "outputs": compare_outputs(legacy, reports[1]),
            "scope": "Historical independent B=1 implementation; not used as the denominator for the contemporaneous batch comparison.",
        })
    (RUNS / "assessment.json").write_text(json.dumps(assessment, indent=2) + "\n")
    print(json.dumps({"runs": [{k: r[k] for k in ("dataset", "batch_size", "status", "observations", "metrics", "peak_allocated_gib", "peak_reserved_gib")} for r in assessment["runs"]], "comparisons": assessment["comparisons"]}, indent=2))


if __name__ == "__main__":
    main()
