"""Serial experiment supervisor; artifacts are intentionally outside tracked code."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path('/mnt/zhouzhenyuan/activevln-vllm-0.30.0-20260925')
SOURCE = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
PYTHON = '/mnt/zhouzhenyuan/venvs/activevln-vllm-0.30.0/bin/python'
BENCHMARK = ROOT / 'benchmarks/activevln-benchmark/benchmark_vllm_modern.py'
CONFIGS = SOURCE / 'benchmarks/activevln-benchmark/runs/batch-tree-shared-context'
ENV = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(SOURCE),
           OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false',
           VLLM_ENABLE_V1_MULTIPROCESSING='0', VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1',
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TORCHINDUCTOR_COMPILE_THREADS='4',
           TORCHINDUCTOR_CACHE_DIR='/tmp/activevln-vllm030-inductor', TMPDIR=str(ROOT / 'tmp'))
STATE = json.loads((ROOT / 'modern-expanded-supervisor-status.json').read_text())
OLD_PARENT = STATE['pid']
STATE.update(status='waiting_for_cancelled_startup', pid=os.getpid(), superseded_parent=OLD_PARENT)


def save():
    p = ROOT / 'modern-status.tmp'
    p.write_text(json.dumps(STATE, indent=2) + '\n')
    p.replace(ROOT / 'modern-status.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assess(report, expected):
    rows = report['rows']
    audits = [r['input_audit'] for r in rows if 'input_audit' in r]
    checks = {
        'complete': report['status'] == 'complete',
        'coverage': len(rows) == expected,
        'unique_rows': len({(r['episode_id'], r['step']) for r in rows}) == expected,
        'valid_actions': all(r['parsed_valid'] for r in rows),
        'vision_graphs': all(r['vision_graph_hits'] > 0 and r['vision_graph_misses'] == 0 for r in rows),
        'inputs': len(audits) == 2 * len(report['selection']) and all(
            all(a[k] for k in ('tokens_equal', 'pixels_equal', 'grid_equal', 'raw_pixels_equal', 'normalized_bf16_equal'))
            for a in audits),
        'source': report['runtime_source_sha256'] == STATE['source_sha256'],
        'full_history': all(r['history_images'] == r['step'] + 1 for r in rows),
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'e2e_ms': report.get('metrics', {}).get('latency_ms', {}).get('mean')}


def execute(name, config, profile, speculative_tokens=16, async_scheduling=None):
    assert sha(BENCHMARK) == STATE['source_sha256'], 'benchmark changed during experiment'
    target = ROOT / f'{name}.json'
    assert not target.exists() and not (ROOT / f'{name}.log').exists(), name
    memory = int(subprocess.check_output(['nvidia-smi', '--id=1', '--query-gpu=memory.used', '--format=csv,noheader,nounits'], text=True).strip())
    assert memory < 100, f'GPU1 occupied: {memory} MiB'
    cmd = [PYTHON, '-u', str(BENCHMARK), '--config', str(config), '--output', str(target),
           '--speculation', profile, '--speculative-tokens', str(speculative_tokens)]
    if async_scheduling is not None:
        cmd.append('--async-scheduling' if async_scheduling else '--no-async-scheduling')
    entry = {'name': name, 'profile': profile, 'speculative_tokens': speculative_tokens, 'async_scheduling': async_scheduling, 'command': cmd, 'started_unix': time.time()}
    STATE['runs'].append(entry)
    STATE.update(status='running', current=name)
    with (ROOT / f'{name}.log').open('w') as log:
        child = subprocess.Popen(cmd, cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT)
        entry['pid'] = child.pid
        save()
        entry['returncode'] = child.wait()
    entry['ended_unix'] = time.time()
    if target.exists():
        report = json.loads(target.read_text())
        expected = sum(ep['frames'] for ep in report['selection'])
        entry['assessment'] = assess(report, expected)
        entry['artifact_sha256'] = sha(target)
        entry['status'] = report['status']
        entry['exception'] = report.get('exception')
    save()
    return entry


save()
try:
    entry = STATE['runs'][-1]
    assert entry['name'] == 'r2r-full-selected' and entry['status'] == 'cancelled_before_measurement'
    pid = entry['pid']
    while Path(f'/proc/{pid}').exists():
        if Path(f'/proc/{pid}/stat').read_text().split()[2] == 'Z':
            break
        time.sleep(5)
    wait_status = int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[49])
    entry['returncode'] = os.waitstatus_to_exitcode(wait_status)
    import signal
    parent_cmd = Path(f'/proc/{OLD_PARENT}/cmdline').read_bytes()
    assert b'run-modern-expanded.py' in parent_cmd
    os.kill(OLD_PARENT, signal.SIGTERM)
    os.kill(OLD_PARENT, signal.SIGCONT)
    save()
    tune_config = ROOT / 'r2r-tuning-10-config.json'
    execute('r2r-tune-ngram_gpu-16-sync', tune_config, 'ngram_gpu', 16, False)
    candidates = STATE['runs'].copy()
    valid = [r for r in candidates if r['returncode'] == 0 and r.get('assessment', {}).get('passed')]
    assert valid, 'no candidate passed'
    winner = min(valid, key=lambda r: r['assessment']['e2e_ms'])
    STATE['selected_profile'] = winner['profile']
    STATE['selected_candidate'] = winner['name']
    STATE['selection_rule'] = 'Lowest mean CPU-RGB-to-CPU-action E2E among passing 10-episode R2R candidates.'
    save()
    for split in ('r2r', 'rxr'):
        entry = execute(f'{split}-full-final', CONFIGS / f'{split}-b1-config.json', winner['profile'],
                        winner.get('speculative_tokens',16), winner.get('async_scheduling'))
        assert entry['returncode'] == 0 and entry.get('assessment', {}).get('passed'), f'{split} full replay failed'
    STATE.update(status='complete', ended_unix=time.time())
    save()
except BaseException as error:
    STATE.update(status='error', error=repr(error), traceback=traceback.format_exc(), ended_unix=time.time())
    save()
    raise
