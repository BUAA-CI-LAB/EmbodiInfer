"""Independently check completed modern experiments against frozen replay inputs."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'batch-tree-shared-context'
result = {'scope': 'B1 fixed saved-frame replay; BF16, complete own history; not closed-loop SR/SPL.', 'runs': {}}
for path in sorted(ROOT.glob('*.json')):
    if '-full-' not in path.stem and '-tune-' not in path.stem:
        continue
    report = json.loads(path.read_text())
    if report.get('status') != 'complete':
        result['runs'][path.stem] = {'status': report.get('status'), 'exception': report.get('exception')}
        continue
    split = path.stem.split('-')[0]
    reference = json.loads((BASE / f'{split}-b1.json').read_text())
    count = report['reference_config']['datasets'][0]['episode_limit']
    assert report['selection'] == reference['selection'][:count]
    if '-full-' in path.stem:
        assert report['reference_config'] == reference['config']
        assert report['selection_sha256'] == reference['selection_sha256']
    rows = report['rows']
    expected = {(ep['episode_id'], i) for ep in report['selection'] for i in range(ep['frames'])}
    keys = [(r['episode_id'], r['step']) for r in rows]
    assert len(keys) == len(set(keys)) and set(keys) == expected
    assert all(r['history_images'] == r['step'] + 1 for r in rows)
    assert all(r['vision_calls'] == 1 and r['vision_graph_hits'] == 1 and r['vision_graph_misses'] == 0 for r in rows)
    assert all(0 < r['model_timing_ms']['pure_inference_ms'] <= r['latency_ms'] for r in rows)
    assert all(r['generated_tokens'] == len(r['token_ids']) for r in rows)
    assert all(r['accepted_draft_tokens'] <= r['verified_draft_tokens'] for r in rows)
    audits = [r['input_audit'] for r in rows if 'input_audit' in r]
    assert len(audits) == 2 * count
    assert all(all(a[k] for k in ('tokens_equal', 'pixels_equal', 'grid_equal', 'raw_pixels_equal', 'normalized_bf16_equal')) for a in audits)
    lookup = {(r['episode_id'], r['step']): r for r in reference['rows']}
    graph_modes = Counter()
    for r in rows:
        graph_modes.update(r['graph_modes'])
    stats = {
        'status': 'complete', 'frames': len(rows), 'episodes': count,
        'artifact_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'runtime_source_sha256': report['runtime_source_sha256'],
        'common_source_sha256': report['benchmark_sha256'],
        'environment': report['environment'], 'optimization_evidence': report['optimization_evidence'],
        'metrics': report['metrics'], 'memory_gib': {k: v / 2**30 for k, v in report['memory'].items()},
        'invalid_actions': sum(not r['parsed_valid'] for r in rows),
        'input_audits': len(audits), 'vision_graph_hits': sum(r['vision_graph_hits'] for r in rows),
        'vision_graph_misses': sum(r['vision_graph_misses'] for r in rows),
        'graph_modes': dict(graph_modes),
        'forward_steps_per_frame': sum(graph_modes.values()) / len(rows),
        'verified_draft_tokens': sum(r['verified_draft_tokens'] for r in rows),
        'accepted_draft_tokens': sum(r['accepted_draft_tokens'] for r in rows),
        'mean_generated_tokens': statistics.mean(r['generated_tokens'] for r in rows),
        'mean_admission_ms': statistics.mean(r['cpu_preparation_and_admission_ms'] for r in rows),
        'mean_outside_forward_ms': statistics.mean(r['latency_ms'] - r['model_timing_ms']['pure_inference_ms'] for r in rows),
        'noninitial_prefix_hits': sum(r['step'] > 0 and r['prefix_cached_tokens'] > 0 for r in rows),
        'noninitial_calls': sum(r['step'] > 0 for r in rows),
        'max_prompt_tokens': max(r['prompt_tokens'] for r in rows),
        'baseline_actions_equal': sum(r['actions'] == lookup[r['episode_id'], r['step']]['actions'] for r in rows),
        'baseline_tokens_equal': sum(r['token_ids'] == lookup[r['episode_id'], r['step']]['token_ids'] for r in rows),
        'history_buckets': {},
    }
    for lo, hi in ((0, 1), (1, 16), (16, 32), (32, 64), (64, 96), (96, 148)):
        bucket = [r for r in rows if lo <= r['step'] < hi]
        if bucket:
            stats['history_buckets'][f'{lo}:{hi}'] = {
                'frames': len(bucket),
                'e2e_ms': statistics.mean(r['latency_ms'] for r in bucket),
                'forward_ms': statistics.mean(r['model_timing_ms']['pure_inference_ms'] for r in bucket),
                'admission_ms': statistics.mean(r['cpu_preparation_and_admission_ms'] for r in bucket),
            }
    result['runs'][path.stem] = stats
    if path.stem == 'r2r-full-final':
        tuning = json.loads((ROOT / 'r2r-tune-ngram_gpu-16-sync.json').read_text())
        assert report['engine_options'] == tuning['engine_options']
        assert report['runtime_source_sha256'] == tuning['runtime_source_sha256']
        original = tuning['rows']
        repeated = rows[:len(original)]
        assert [(r['episode_id'],r['step']) for r in original] == [(r['episode_id'],r['step']) for r in repeated]
        mean_e2e = statistics.mean(r['latency_ms'] for r in repeated)
        mean_forward = statistics.mean(r['model_timing_ms']['pure_inference_ms'] for r in repeated)
        stats['repeat_of_tuning'] = {
            'frames': len(original),
            'different_token_rows': sum(a['token_ids'] != b['token_ids'] for a,b in zip(original,repeated)),
            'different_action_rows': sum(a['actions'] != b['actions'] for a,b in zip(original,repeated)),
            'e2e_ms': mean_e2e,
            'forward_ms': mean_forward,
            'e2e_relative_change': mean_e2e/tuning['metrics']['latency_ms']['mean']-1,
            'forward_relative_change': mean_forward/tuning['metrics']['model_timing_ms']['pure_inference_ms']['mean']-1,
        }
    print(path.stem, len(rows), report['metrics']['latency_ms']['mean'], report['metrics']['model_timing_ms']['pure_inference_ms']['mean'], dict(graph_modes))
result['complete'] = all(result['runs'].get(n, {}).get('status') == 'complete'
                         for n in ('r2r-full-final', 'rxr-full-final'))
(ROOT / 'assessment-modern.json').write_text(json.dumps(result, indent=2) + '\n')
