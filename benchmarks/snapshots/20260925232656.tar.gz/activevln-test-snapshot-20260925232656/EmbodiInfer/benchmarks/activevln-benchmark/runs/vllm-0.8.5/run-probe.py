"""Wait for the isolated installation, then run an audited short GPU-1 replay."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/mnt/zhouzhenyuan/activevln-vllm-20260925')
source = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
python = '/mnt/zhouzhenyuan/venvs/activevln-vllm-0.8.5/bin/python'
env = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(source),
           OMP_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false',
           VLLM_USE_V1='1', VLLM_ENABLE_V1_MULTIPROCESSING='0',
           VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1', HF_HUB_OFFLINE='1',
           TRANSFORMERS_OFFLINE='1', TORCHINDUCTOR_COMPILE_THREADS='4',
           TORCHINDUCTOR_CACHE_DIR='/tmp/activevln-vllm085-inductor',
           TMPDIR=str(root/'tmp'))
state = {'status':'waiting_install', 'install_pid':2502287}
def save():
    p=root/'probe-status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'probe-status.json')
save()
while Path('/proc/2502287/stat').exists() and Path('/proc/2502287/stat').read_text().split()[2] != 'Z':
    time.sleep(10)
state['status']='checking_environment';save()
with (root/'environment-check.log').open('w') as log:
    checked = subprocess.run([python,'-c','import torch, vllm, transformers; print(torch.__version__,vllm.__version__,transformers.__version__)'],env=env,stdout=log,stderr=subprocess.STDOUT)
state['environment_returncode']=checked.returncode;save()
if checked.returncode:
    state['status']='environment_error';save();raise SystemExit(checked.returncode)
memory=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
assert int(memory.strip()) < 100, 'GPU1 is still occupied'
command=[python,'-u',str(root/'benchmarks/activevln-benchmark/benchmark_vllm.py'),
         '--config',str(source/'benchmarks/activevln-benchmark/runs/batch-tree-shared-context/r2r-b1-config.json'),
         '--output',str(root/'r2r-probe-default-graphs.json'),'--max-steps-per-episode','2']
state.update(status='running_probe',command=command,started_unix=time.time());save()
with (root/'r2r-probe-default-graphs.log').open('w') as log:
    process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    state['pid']=process.pid;save();state['returncode']=process.wait()
state.update(status='probe_finished',ended_unix=time.time());save()
