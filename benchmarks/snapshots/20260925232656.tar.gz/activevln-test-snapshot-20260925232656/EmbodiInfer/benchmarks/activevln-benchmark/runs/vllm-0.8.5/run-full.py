"""Serialize the two full replays, then restore the interrupted quality pipeline."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/mnt/zhouzhenyuan/activevln-vllm-20260925')
source = Path('/mnt/zhouzhenyuan/activevln-batch-tree-shared-context-20260925')
python = '/mnt/zhouzhenyuan/venvs/activevln-vllm-0.8.5/bin/python'
benchmark = root/'benchmarks/activevln-benchmark/benchmark_vllm.py'
env = dict(os.environ, CUDA_VISIBLE_DEVICES='1', PYTHONPATH=str(source),
           OMP_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false',
           VLLM_USE_V1='1', VLLM_ENABLE_V1_MULTIPROCESSING='0',
           VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1', HF_HUB_OFFLINE='1',
           TRANSFORMERS_OFFLINE='1', TORCHINDUCTOR_COMPILE_THREADS='4',
           TORCHINDUCTOR_CACHE_DIR='/tmp/activevln-vllm085-inductor',
           TMPDIR=str(root/'tmp'))
state = {'status':'starting', 'supervisor_pid':os.getpid(), 'started_unix':time.time(),
         'benchmark_sha256':hashlib.sha256(benchmark.read_bytes()).hexdigest(), 'runs':[]}
def save():
    p=root/'full-status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'full-status.json')
save()
try:
    for split in ['r2r', 'rxr']:
        memory=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
        assert int(memory.strip()) < 100, 'GPU1 is occupied'
        assert hashlib.sha256(benchmark.read_bytes()).hexdigest() == state['benchmark_sha256']
        output=root/f'{split}-full.json'
        assert not output.exists(), f'refusing to overwrite {output}'
        command=[python,'-u',str(benchmark),'--config',str(source/f'benchmarks/activevln-benchmark/runs/batch-tree-shared-context/{split}-b1-config.json'),'--output',str(output)]
        run={'split':split,'command':command,'started_unix':time.time()}
        state['runs'].append(run);state.update(status='running',current=split);save()
        with (root/f'{split}-full.log').open('x') as log:
            process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
            run['pid']=process.pid;save();run['returncode']=process.wait()
        run['ended_unix']=time.time();save()
        if run['returncode']:
            raise RuntimeError(f'{split} failed with returncode {run["returncode"]}')
    state.update(status='complete',ended_unix=time.time());save()
except BaseException as error:
    state.update(status='error',error=repr(error),ended_unix=time.time());save()
finally:
    previous=Path('/proc/2499022/cmdline')
    if previous.exists() and b'run-pipeline.py' in previous.read_bytes():
        os.kill(2499022,signal.SIGCONT)
        state['quality_pipeline_resumed_pid']=2499022
    else:
        state['quality_pipeline_resume_error']='Original supervisor no longer matches'
    save()
