"""Validate complete saved-frame native batch reports independently of the runner."""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
import statistics

ROOT = Path(__file__).parent
BASE = ROOT.parent / 'batch-tree-shared-context'
SINGLE = ROOT.parent / 'vllm-0.30.0'

def expected_batches(selection, size):
    pending=iter(selection)
    active=[]
    result=[]
    while True:
        while len(active)<size:
            ep=next(pending,None)
            if ep is None:
                break
            active.append([ep['episode_id'],0,ep['frames']])
        if not active:
            return result
        result.append([(ep,step) for ep,step,_ in active])
        for item in active:
            item[1]+=1
        active=[item for item in active if item[1]<item[2]]

def assess(path):
    report=json.loads(path.read_text())
    split=report['dataset'].lower()
    batch=report['batch_size']
    config=json.loads((BASE/f'{split}-b{batch}-config.json').read_text())
    assert report['reference_config']==config
    reference=json.loads((BASE/f'{split}-b{batch}.json').read_text())
    assert report['selection']==reference['selection']
    assert report['selection_sha256']==reference['selection_sha256']
    assert all(hashlib.sha256((ROOT.parents[1]/name).read_bytes()).hexdigest()==value for name,value in report['source_sha256'].items())
    assert report['cuda_visible_devices']=='1'
    assert report['environment']['vllm']=='0.30.0'
    assert report['warmup']['batch_calls']==33
    options=report['engine_options']
    assert options['max_num_seqs']==batch
    assert all(1037*n in options['compilation_config']['cudagraph_capture_sizes'] for n in range(1,batch+1))
    assert options['speculative_config']['method']=='ngram_gpu'
    assert options['speculative_config']['num_speculative_tokens']==16
    assert options['async_scheduling'] is False
    assert options['enable_prefix_caching'] and options['optimization_level']==3
    assert options['compilation_config']['encoder_cudagraph_max_vision_items_per_batch']==batch
    rows=report['rows']; batches=report['batches']
    plan=expected_batches(report['selection'],batch)
    actual=[[] for _ in batches]
    last_history={}
    delta_lengths={}
    for row in rows:
        actual[row['batch_index']].append((row['episode_id'],row['step']))
        assert row['history_images']==row['step']+1
        assert row['cache_length']==row['prompt_tokens']+len(row['token_ids'])
        assert row['generated_tokens']==len(row['token_ids'])
        assert row['prefix_cached_tokens']<=row['prompt_tokens']
        if row['episode_id'] in last_history:
            old=last_history[row['episode_id']]
            assert row['step']==old['step']+1
            delta=row['prompt_tokens']-old['cache_length']
            assert delta>0, 'history reset or truncated'
            if row['episode_id'] in delta_lengths:
                assert delta==delta_lengths[row['episode_id']], 'history or image expansion changed'
            delta_lengths[row['episode_id']]=delta
        last_history[row['episode_id']]=row
        assert row['parsed_valid']
        if row['step']<2:
            audit=row['input_audit']
            assert all(audit[k] for k in ('tokens_equal','raw_pixels_equal','normalized_bf16_equal','grid_equal'))
        if row['step']==0:
            assert row['prefix_cached_tokens']==0, 'cross-episode prefix reuse'
        else:
            assert row['prefix_cached_tokens']>0, 'own episode prefix missed'
    assert actual==plan[:len(actual)]
    modes=Counter(); scheduled=Counter()
    for b in batches:
        assert b['observations']==len(actual[b['batch_index']])
        assert b['vision_items']==b['observations'] and b['vision_graph_hits']>0 and b['vision_graph_misses']==0
        assert b['graph_modes'].get('NONE',0)==0
        assert 0<b['model_timing_ms']['pure_inference_ms']<=b['latency_ms']
        modes.update(b['graph_modes'])
        scheduled.update({int(k):v for k,v in b['scheduled_batch_sizes'].items()})
    if report['status']=='complete':
        assert len(actual)==len(plan)
        assert len(rows)==report['expected_observations']==sum(ep['frames'] for ep in report['selection'])
        assert len(report['selection'])==48
    else:
        assert report['status']=='oom'
    count=len(rows)
    total_e2e=sum(b['latency_ms'] for b in batches)
    total_forward=sum(b['model_timing_ms']['pure_inference_ms'] for b in batches)
    m=report['metrics']
    assert math.isclose(total_e2e/count,m['amortized_e2e_ms_per_observation'])
    assert math.isclose(total_forward/count,m['amortized_forward_ms_per_observation'])
    assert math.isclose(count*1000/total_e2e,m['observations_per_second'])
    single=json.loads((SINGLE/f'{split}-full-final.json').read_text())
    lookup={(r['episode_id'],r['step']):r for r in single['rows']}
    return {
        'status':report['status'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'observations':count,'batches':len(batches),'metrics':m,
        'peak_allocated_gib':report['memory']['peak_allocated_bytes']/2**30,
        'peak_reserved_gib':report['memory']['peak_reserved_bytes']/2**30,
        'graph_modes':dict(modes),'scheduled_request_counts':dict(scheduled),
        'mean_active_requests_per_language_call':sum(k*v for k,v in scheduled.items())/sum(scheduled.values()),
        'language_calls_per_batch':sum(scheduled.values())/len(batches),
        'vision_calls':sum(b['vision_calls'] for b in batches),
        'vision_graph_hits':sum(b['vision_graph_hits'] for b in batches),
        'vision_items':sum(b['vision_items'] for b in batches),
        'preemptions':sum(b['preemptions'] for b in batches),
        'input_audits':sum('input_audit' in r for r in rows),
        'mean_admission_ms':statistics.mean(b['cpu_preparation_and_admission_ms'] for b in batches),
        'mean_generated_tokens':statistics.mean(r['generated_tokens'] for r in rows),
        'max_prompt_tokens':max(r['prompt_tokens'] for r in rows),
        'max_aggregate_cache_tokens':max(sum(r['cache_length'] for r in rows if r['batch_index']==b['batch_index']) for b in batches),
        'b1_token_matches':sum(r['token_ids']==lookup[(r['episode_id'],r['step'])]['token_ids'] for r in rows),
        'b1_action_matches':sum(r['actions']==lookup[(r['episode_id'],r['step'])]['actions'] for r in rows),
        'e2e_throughput_speedup_vs_b1':single['metrics']['latency_ms']['mean']/m['amortized_e2e_ms_per_observation'],
        'all_contract_checks_passed':True,
    }

if __name__=='__main__':
    assessed={}
    for split in ('r2r','rxr'):
        for batch in (2,4):
            path=ROOT/f'{split}-b{batch}-full.json'
            if path.exists():
                assessed[path.stem]=assess(path)
    (ROOT/'assessment.json').write_text(json.dumps(assessed,indent=2)+'\n')
    print(json.dumps(assessed,indent=2))
