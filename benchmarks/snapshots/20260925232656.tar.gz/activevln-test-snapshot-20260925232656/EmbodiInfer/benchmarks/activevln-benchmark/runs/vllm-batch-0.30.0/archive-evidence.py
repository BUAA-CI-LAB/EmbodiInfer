import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root=Path('/mnt/zhouzhenyuan/activevln-vllm-batch-0.30.0-20260925')
status=json.loads((root/'batch-final-status.json').read_text())
assert status['status']=='finished'
shutil.copyfile('/mnt/zhouzhenyuan/activevln-vllm-0.30.0-20260925/requirements.txt', root/'requirements.txt')
files=[p for p in root.rglob('*') if p.is_file() and p.suffix in ('.json','.py','.log','.txt') and not {'tmp','__pycache__'}.intersection(p.relative_to(root).parts) and p.name!='artifact-manifest.json']
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(root/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(root/'artifact-manifest.json')
archive=root/'batch-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as bundle:
    for p in sorted(files):
        bundle.add(p,arcname=str(p.relative_to(root)))
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)}))
